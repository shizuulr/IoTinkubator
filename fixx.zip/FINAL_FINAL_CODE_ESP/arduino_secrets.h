//arduino_secrets.h header file
#define SECRET_SSID "tselhome_9B11"
#define SECRET_PASS "64HTaA8EqYm"